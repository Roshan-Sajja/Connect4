List of files:
1. Gameboard.css     : 	Styling for the webpage Gameboard.html
2. Gameboard.html    : 	Webpage for playing the game.
3. gameboardDesign.js: 	For rendering the connect 4 grid.

4. Home.css          : 	Styling for the webpage Home.html
5. Home.html         : 	Home page for the connect 4 game.
  
6. howToPlay.css     : 	Styling for the webpage howToPlay.html
7. howToPlay.html    : 	Instructions for playing the game.

8. Log in.css        : 	Styling for the webpage Log in.html
9. Log in.html       : 	The log in page for a user.
10. logInTest.js     : 	Test functionality for input in the username and password text boxes.

11. userProfile.css  : 	Styling for the webpage userProfile.html
12. userProfile.html : 	Displays the user's profile.

13. viewProfile.css  : 	Styling for the webpage viewProfile.html
14. viewProfile.html : 	Displays a friend's profile 

Project working on: CONNECT4

Name of partners:
1. Name: Roshan Sajja
   Student ID: 101168617

2. Name: Ricky Gulati
   Student ID: 101146071

Additional dynamic behaviour through javaScript: Log in test functionality on button click to check if user has input in both username and password text boxes.
				File to refer  : logInTest.js
